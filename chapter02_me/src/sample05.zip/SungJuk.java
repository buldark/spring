package sample05;

import java.util.ArrayList;

public interface SungJuk {
	public void execute();
}
